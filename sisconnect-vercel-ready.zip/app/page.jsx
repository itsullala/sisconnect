"use client";
import { useState } from "react";
import { Card, CardContent } from "../components/ui/card";
import { Input } from "../components/ui/input";
import { Button } from "../components/ui/button";
import { Textarea } from "../components/ui/textarea";

export default function Home() {
  const [chatMessages, setChatMessages] = useState([]);
  const [message, setMessage] = useState("");
  const [memeLink, setMemeLink] = useState("");
  const [memes, setMemes] = useState([]);
  const [videoCallStarted, setVideoCallStarted] = useState(false);

  const sendMessage = () => {
    if (message.trim() !== "") {
      setChatMessages([...chatMessages, { sender: "You", text: message }]);
      setMessage("");
    }
  };

  const shareMeme = () => {
    if (memeLink.trim() !== "") {
      setMemes([...memes, memeLink]);
      setMemeLink("");
    }
  };

  const startVideoCall = () => {
    setVideoCallStarted(true);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-100 to-indigo-200 p-4 space-y-8">
      <div className="max-w-3xl mx-auto bg-white shadow-xl rounded-2xl p-6 space-y-4">
        <h1 className="text-4xl font-bold text-center text-pink-700">SisConnect 💬</h1>
        <p className="text-center text-gray-600">Welcome! Chat, call, and share memes with your sister 💖</p>
      </div>

      <div className="max-w-3xl mx-auto bg-white shadow-md rounded-xl p-4 space-y-3">
        <h2 className="text-xl font-semibold text-indigo-600">💬 Chat</h2>
        <div className="h-40 overflow-y-auto border p-2 rounded bg-gray-50">
          {chatMessages.map((msg, idx) => (
            <p key={idx}><strong>{msg.sender}:</strong> {msg.text}</p>
          ))}
        </div>
        <div className="flex space-x-2">
          <Input
            type="text"
            placeholder="Type a message..."
            value={message}
            onChange={(e) => setMessage(e.target.value)}
          />
          <Button onClick={sendMessage}>Send</Button>
        </div>
      </div>

      <div className="max-w-3xl mx-auto bg-white shadow-md rounded-xl p-4 space-y-3">
        <h2 className="text-xl font-semibold text-indigo-600">📸 Meme Sharing</h2>
        <div className="flex space-x-2">
          <Input
            type="text"
            placeholder="Paste meme link (Insta/Twitter)"
            value={memeLink}
            onChange={(e) => setMemeLink(e.target.value)}
          />
          <Button onClick={shareMeme}>Share</Button>
        </div>
        <div className="grid grid-cols-2 gap-2 mt-2">
          {memes.map((link, idx) => (
            <iframe
              key={idx}
              src={link}
              className="w-full h-48 rounded border"
              title={`meme-${idx}`}
              allow="fullscreen"
            />
          ))}
        </div>
      </div>

      <div className="max-w-3xl mx-auto bg-white shadow-md rounded-xl p-4 space-y-3">
        <h2 className="text-xl font-semibold text-indigo-600">📹 Video Call</h2>
        {!videoCallStarted ? (
          <Button onClick={startVideoCall}>Start Call</Button>
        ) : (
          <div className="bg-black text-white p-10 text-center rounded">
            <p>🔴 Video Call Simulated (WebRTC can be added)</p>
          </div>
        )}
      </div>
    </div>
  );
}
